// Log.cpp: implementation of the CLog class.
//
//////////////////////////////////////////////////////////////////////

#include "clib.h"



/*
* log.cpp - implement logging functions.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>

#ifndef WIN32
#include <errno.h>
#include <syslog.h>
#else
#include <windows.h>
#endif

#ifdef _xlC
#include <strings.h>
#endif


//#include "../config.h"
#include "protected.h"
#include "Thread.h"
#include "Time.h"
#include "Lock.h"

#include "include.h"

#include "log.h"
/*
* List of currently open log files.
*/
#define MAX_LOGFILES 8
static struct {
    FILE *file;
    int minimum_output_level;
    char filename[FILENAME_MAX + 1]; /* to allow re-open */
} logfiles[MAX_LOGFILES];
static int num_logfiles = 0;


/*
* List of places that should be logged at debug-level.
*/
#define MAX_LOGGABLE_PLACES (10*1000)
static char *loggable_places[MAX_LOGGABLE_PLACES];
static int num_places = 0;


/*
* Syslog support.
*/
static int sysloglevel;
static int dosyslog = 0;

/*
* Debug switch support.
*/
static int 	log_g_i_need_debug = 1;

/*
* Make sure stderr is included in the list.
*/
static void add_stderr(void) 
{
    int i;
    
    for (i = 0; i < num_logfiles; ++i)
		if (logfiles[i].file == stderr)
			return;
		logfiles[num_logfiles].file = stderr;
		logfiles[num_logfiles].minimum_output_level = LOG_DEBUG;
		++num_logfiles;
}


void set_output_level(enum output_level level) 
{
    int i;
    
    add_stderr();
    for (i = 0; i < num_logfiles; ++i) {
		if (logfiles[i].file == stderr) {
			logfiles[i].minimum_output_level = level;
			break;
		}
    }
}

#ifndef WIN32
void set_syslog(const char *ident, int syslog_level) 
{
    if (ident == NULL)
		dosyslog = 0;
    else {
		dosyslog = 1;
		sysloglevel = syslog_level;
		openlog(ident, LOG_PID, LOG_DAEMON);
    }
}
#endif

void reopen_log_files(void) 
{
	int i;
	
    for (i = 0; i < num_logfiles; ++i) {
		if (logfiles[i].file != stderr) {
			fclose(logfiles[i].file);
			logfiles[i].file = fopen(logfiles[i].filename, "a");
			if (logfiles[i].file == NULL) {
				error(errno, "Couldn't re-open logfile `%s'.",
					logfiles[i].filename);
			}
		}
    }		
}


void close_all_logfiles(void) 
{
    while (num_logfiles > 0) {
		--num_logfiles;
		if (logfiles[num_logfiles].file != stderr)
			fclose(logfiles[num_logfiles].file);
		logfiles[num_logfiles].file = NULL;
    }
}


void open_logfile(char *filename, int level) 
{
    FILE *f;
    
    add_stderr();
    if (num_logfiles == MAX_LOGFILES) {
		error(0, "Too many log files already open, not adding `%s'", 
			filename);
		return;
    }
    
    if (strlen(filename) > FILENAME_MAX) {
		error(0, "Log filename too long: `%s'.", filename);
		return;
    }
    
    f = fopen(filename, "a");
    if (f == NULL) {
		error(errno, "Couldn't open logfile `%s'.", filename);
		return;
    }
    
    logfiles[num_logfiles].file = f;
    logfiles[num_logfiles].minimum_output_level = level;
    strcpy(logfiles[num_logfiles].filename, filename);
    ++num_logfiles;
    info(0, "Added logfile `%s' with level `%d'.", filename, level);
}


#define FORMAT_SIZE (10*1024)
static void format(char *buf, int level, const char *place, int e, 
				   const char *fmt)
{
    static char *tab[] = {
		"DEBUG: ",
			"INFO: ",
			"WARNING: ",
			"ERROR: ",
			"PANIC: ",
			"LOG: "
    };
    static int tab_size = sizeof(tab) / sizeof(tab[0]);
    time_t t;
    struct tm tm;
    char *p, prefix[1024];
    
    p = prefix;
    time(&t);
#if LOG_TIMESTAMP_LOCALTIME
    tm = localtime(t);
#else
    tm = gmtime(t);
#endif
    sprintf(p, "%04d-%02d-%02d %02d:%02d:%02d ",
		tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
		tm.tm_hour, tm.tm_min, tm.tm_sec);
    
    p = strchr(p, '\0');
#ifndef WIN32
    sprintf(p, "[%ld] ", ThreadSelf());
#else
	sprintf(p, "[%ld] ", GetCurrentThreadId());
#endif
    
    p = strchr(p, '\0');
    if (level < 0 || level >= tab_size)
		sprintf(p, "UNKNOWN: ");
    else
		sprintf(p, "%s", tab[level]);
    
    p = strchr(p, '\0');
    if (place != NULL && *place != '\0')
		sprintf(p, "%s: ", place);
    
    if (strlen(prefix) + strlen(fmt) > FORMAT_SIZE / 2) {
		sprintf(buf, "%s <OUTPUT message too long>\n", prefix);
		return;
    }
    
    if (e == 0)
		sprintf(buf, "%s%s\n", prefix, fmt);
    else
		sprintf(buf, "%s%s\n%sSystem error %d: %s\n",
		prefix, fmt, prefix, e, strerror(e));
}


static void output(FILE *f, char *buf, va_list args) 
{
    vfprintf(f, buf, args);
    fflush(f);
}


#ifndef WIN32
static void ss_syslog(char *format, va_list args, int level)
{
    char buf[4096]; /* Trying to syslog more than 4K could be bad */
    int translog;
    
    if (level >= sysloglevel && dosyslog) {
		vsnprintf(buf, sizeof(buf), format, args);
		/* XXX vsnprint not 100% portable */
		
		switch(level) {
		case LOG_DEUG:
			translog = LOG_DEBUG;
			break;
		case LOG_INFO:
			translog = LOG_INFO;
			break;
		case LOG_WARNING:
			translog = LOG_WARNING;
			break;
		case LOG_ERROR:
			translog = LOG_ERR;
			break;
		case LOG_PANIC:
			translog = LOG_ALERT;
			break;
		default:
			translog = LOG_INFO;
			break;
		}
		syslog(translog,buf);
    }
}
#endif

/*
* Almost all of the message printing functions are identical, except for
* the output level they use. This macro contains the identical parts of
* the functions so that the code needs to exist only once. It's a bit
* more awkward to edit, but that can't be helped. The "do {} while (0)"
* construct is a gimmick to be more like a function call in all syntactic
* situation.
*/

#define FUNCTION_GUTS(level, place) \
	do { \
	int i; \
	char buf[FORMAT_SIZE]; \
	va_list args; \
	\
	add_stderr(); \
	format(buf, level, place, e, fmt); \
	for (i = 0; i < num_logfiles; ++i) { \
	if (level >= logfiles[i].minimum_output_level) { \
	va_start(args, fmt); \
	output(logfiles[i].file, buf, args); \
	va_end(args); \
	} \
	/*		if (dosyslog) { */\
	/*		    va_start(args, fmt); */\
	/*		    ss_syslog(buf,args,level); */\
	/*		    va_end(args); */\
	/*		} */\
	} \
	} while (0)


void panic(int e, const char *fmt, ...) 
{
    FUNCTION_GUTS(LOG_PANIC, "");
    exit(EXIT_FAILURE);
}


void error(int e, const char *fmt, ...) 
{
    FUNCTION_GUTS(LOG_ERROR, "");
}


void warning(int e, const char *fmt, ...) 
{
    FUNCTION_GUTS(LOG_WARNING, "");
}


void info(int e, const char *fmt, ...) 
{
	FUNCTION_GUTS(LOG_INFO, "");
}


static int place_matches(const char *place, const char *pat) 
{
    size_t len;
    
    len = strlen(pat);
    if (pat[len-1] == '*')
#ifndef WIN32
		return (strncasecmp(place, pat, len - 1) == 0);
#else
	return (strnicmp(place, pat, len - 1) == 0);
#endif
	
#ifndef WIN32
    return (strcasecmp(place, pat) == 0);
#else
	return (stricmp(place, pat) == 0);
#endif
}


static int place_should_be_logged(const char *place) 
{
    int i;
    
    if (num_places == 0)
		return 1;
    for (i = 0; i < num_places; ++i) {
		if (*loggable_places[i] != '-' && 
			place_matches(place, loggable_places[i]))
			return 1;
    }
    return 0;
}


static int place_is_not_logged(const char *place) 
{
    int i;
    
    if (num_places == 0)
		return 0;
    for (i = 0; i < num_places; ++i) {
		if (*loggable_places[i] == '-' &&
			place_matches(place, loggable_places[i]+1))
			return 1;
    }
    return 0;
}


void debug(const char *place, int e, const char *fmt, ...) 
{
	// If we don't need output debug information.
	if (log_g_i_need_debug == 0)
		return;
	
    if (place_should_be_logged(place) && place_is_not_logged(place) == 0) {
		FUNCTION_GUTS(LOG_DEBUG, "");
		/*
		* Note: giving `place' to FUNCTION_GUTS makes log lines
		* too long and hard to follow. We'll rely on an external
		* list of what places are used instead of reading them
		* from the log file.
		*/
    }
}


void set_debug_places(const char *places) 
{
    char *p = NULL;
#if 0
    p = strtok(ss_strdup(places), " ,");
    num_places = 0;
    while (p != NULL && num_places < MAX_LOGGABLE_PLACES) {
		loggable_places[num_places++] = p;
		p = strtok(NULL, " ,");
    }
#endif
}

/*
* Switch on or off the debug function.
*
* Added by Zhang Yuan, for normal service. 2001-3-1.
*/
void disable_debug_info(void)
{
	log_g_i_need_debug = 0;
	return;
}

void enable_debug_info(void)
{
	log_g_i_need_debug = 1;
	return;
}

using namespace clib;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMutex CLog::lock;
_log *CLog::defaultLog = NULL;
std::map<std::string, _log*> CLog::logs;

CLog::CLog()
{
	
}

CLog::~CLog()
{
	
}

_log::_log(std::string key){
	bFirstWrite = true;
	
	bError = true;
	bWarning = true;
	bError = true;
	bTrace = true;
	bCache = true;
	bEvent = true;
	
	nTraceLevel = 100000;
	nCacheSize = 1024;
	
	nCurWaitNumber = 0;
	category = key;
	
	toStop.Create(NULL, false, false, NULL);
	waitTime = 10000;
	nMaxWaitNumber = 10;
	CThread::ThreadCreate(sweeper, this);
	
	
	//printf("log started\n");
};

_log::_log(_log& src){
	bFirstWrite = true;

	bError = src.bError;
	bWarning = src.bWarning;
	bError = src.bError;
	bTrace = src.bTrace;
	bCache = src.bCache;
	bEvent = src.bEvent;
	
	nTraceLevel = src.nTraceLevel;
	nCacheSize = src.nCacheSize;
	
	nCurWaitNumber = 0;
	//category = key;
	
	waitTime = src.waitTime;
	nMaxWaitNumber = src.nMaxWaitNumber;
	
	toStop.Create(NULL, false, false, NULL);

	this->file.copy((char*)src.file.c_str(), src.file.length());
	
	CThread::ThreadCreate(sweeper, this);
	//	printf("log started\n");
	
	
	
};

 _log::~_log(){
	//	printf("log %s stoping", category);
	
	event("\n******************* CLib Logging stopped (module=" + category + ")\n");
	toStop.Set();	// notify to stop sweeper
	toStop.Wait();	// wait sweeper over
	
	flush();
	
	toStop.Destroy();
	lock.Destroy();
	
	//		printf("log %s stopped", category);
};
void _log::put(std::string s){
	lock.Lock();
	if (bCache){
		cache.append(s);
	}else{
		putReal(s);
	}
	lock.Unlock();
};

void _log::putReal(std::string s){
	if (s.length() <= 0)
		return;

	if (bFirstWrite)
	{
		s = //"************************************************************\n"
			"\n******************* CLib Logging started (module=" + category + ")\n"
			//"************************************************************\n"
			+ s;
		bFirstWrite = false;

	}


	if (file.length() == 0){	//print to std out
		printf(s.c_str());
		nCurWaitNumber = 0;
		return;
	}
	// assemble file name
	int nIndex = file.find_last_of('.');
	std::string base_name;
	std::string ext_name;
	if (nIndex >= 0)
	{
		base_name = file.substr(0, nIndex);
		ext_name = file.substr(nIndex, file.length());
	}
	else
		base_name = file;			
	
	
	std::string time_str;		
	CTime::GetLocalTimeString(time_str, true, true);
	std::string completeFile = base_name + category + time_str + "." +  ext_name;
	
	
	FILE* pFile = fopen(file.c_str(),"a+");
	if(pFile != NULL)
	{
		fwrite(s.c_str(), sizeof(char), s.length(), pFile);
		fclose(pFile);
	}else{
		printf("open log file(%s) failed", file.c_str());
		;	
	}		
	nCurWaitNumber = 0;
	
};

 void _log::sweeper(void* p){
	_log* pThis = (_log*)p;
	if (!pThis->bCache)
		return;
	
	while (true){
		if (pThis->toStop.Wait(pThis->waitTime) != LOCKEX_ERR_TIMEOUT)
			break;
		if (pThis->cache.length() > pThis->nCacheSize || pThis->nCurWaitNumber >= pThis->nMaxWaitNumber)
			pThis->flush();
		else
			pThis->nCurWaitNumber++;
	}
	pThis->toStop.Set();
}

void _log::setWarning(bool b){
	bWarning = b;
};

void _log::setError(bool b){
	bError = b;
};

void _log::setLog(bool b){
	bLog = b;
}

void _log::setTrace(bool b, int l){
	bLog = b;
	nTraceLevel = l;
}

void _log::setCache(bool b, int size){
	bCache = b;
	if (size >= 0)
		nCacheSize = size;
}

void _log::setFile(std::string sFileName){
	event("log will be redirected to " + sFileName);
	file = std::string(sFileName);
	event("log has been redirected to " + sFileName);
}

void _log::log(std::string s){
	if (!bLog)
		return;
	std::string time_str;
	CTime::GetLocalTimeString(time_str, true, true);
	std::string thread_id;
	thread_id +=  "Thread-";
	char threadid[10] = "";
	ltoa(CThread::ThreadSelf(), threadid, 10);
	thread_id +=  threadid;
	std::string tmp = time_str + " " + "[LOG]\t[" + category + "]\t" + thread_id + "\t"  + s + "\n";
	put(tmp);
}

void _log::error(std::string s){
	if (!bError)
		return;
	std::string time_str;
	std::string thread_id;
	CTime::GetLocalTimeString(time_str, true, true);
	thread_id +=  "Thread-";
	char threadid[10] = "";
	ltoa(CThread::ThreadSelf(), threadid, 10);
	thread_id +=  threadid;
	std::string tmp = time_str + " " + "[ERR]\t[" + category + "]\t" + thread_id + "\t"  + s + "\n";
	put(tmp);
}

void _log::warning(std::string s){
	if (!bWarning)
		return;
	std::string time_str;
	std::string thread_id;
	CTime::GetLocalTimeString(time_str, true, true);
	thread_id +=  "Thread-";
	char threadid[10] = "";
	ltoa(CThread::ThreadSelf(), threadid, 10);
	thread_id +=  threadid;
	std::string tmp = time_str + " " + "[WAR]\t[" + category + "]\t" + thread_id + "\t"  + s + "\n";
	put(tmp);
}

void _log::trace(std::string s, int l){
	if (!bTrace && l > nTraceLevel)
		return;
	std::string time_str;
	std::string thread_id;
	CTime::GetLocalTimeString(time_str, true, true);
	char trace_level[10] = "";
	itoa(l, trace_level, 10);
	thread_id +=  "Thread-";
	char threadid[10] = "";
	ltoa(CThread::ThreadSelf(), threadid, 10);
	thread_id +=  threadid;
	std::string tmp = time_str + " " + "[TRC" + trace_level + "]\t[" + category + "]\t" + thread_id + "\t"  + s + "\n";
	put(tmp);
}

void _log::event(std::string s){
	if (!bEvent)
		return;
	std::string time_str;
	std::string thread_id;
	CTime::GetLocalTimeString(time_str, true, true);
	thread_id +=  "Thread-";
	char threadid[10] = "";
	ltoa(CThread::ThreadSelf(), threadid, 10);
	thread_id +=  threadid;
	std::string tmp = time_str + " " + "[EVT]\t[" + category + "]\t" + thread_id + "\t"  + s + "\n";
	put(tmp);
}

void _log::flush(){
	if (!bCache)
		return;
	putReal(cache);
}

void _log::setCategory(std::string key){
	category = key;
}

 _log* CLog::getDefaultInst(){
		 lock.Lock();
		 if (defaultLog == NULL){
			 defaultLog = new _log("");
		 }
		 lock.Unlock();
		 return defaultLog;
	 }
	 
	 

	 
	 _log* CLog::getInst(std::string key){

		 _log * ret = NULL;
		 if (key.length() == 0)
			 return getDefaultInst();

		 std::string _key;
		 _key.copy((char*)key.c_str(), key.length());
		 
		 // find
		 lock.Lock();

		 std::map<std::string, _log*>::iterator it;
		it = (logs.find(_key));
		 if (it == NULL || it == logs.end()){ // not found, create new one
			 _log* def = getDefaultInst();
			 _log *pNew = new _log(*def);
			 pNew->setCategory(_key);
			 logs.insert(log_pair(_key, pNew));
			 ret = pNew;
		 }
		 else
			 ret = it->second;

		 lock.Unlock();
		 return ret;
	 }
	 
	 
	 
	 bool CLog::set(std::string category, std::string fileName, bool bLog, bool bWarning, bool bError, bool bTrace, int nTraceLevel, bool bCache, int nCacheSize){
		 std::string _category, _filename;
		 _category.copy((char*)category.c_str(), category.length());
		 _filename.copy((char*)fileName.c_str(), fileName.length());
		 
		 _log *pLog = getInst(_category);
		 if (pLog == NULL)
			 return false;
		 pLog->setFile(_filename);
		 pLog->setCache(bCache, nCacheSize);
		 pLog->setError(bError);
		 pLog->setWarning(bWarning);
		 pLog->setLog(bLog);
		 pLog->setTrace(bTrace, nTraceLevel);
		 return true;
	 };
	 
	 void CLog::setFile(std::string category, std::string filename){

		 std::string _category, _filename;
		 _category.copy((char*)category.c_str(), category.length());
		 _filename.copy((char*)filename.c_str(), filename.length());
		 
		 _log *pLog = getInst(_category);
		 if (pLog == NULL)
			 return;
		 
		 if (pLog == defaultLog)
		 {
			 std::map<std::string, _log*>::iterator it;
			 for (it = logs.begin(); it != logs.end(); it++){
				 _log *ele = it->second;
				 ele->setFile(_filename);
			 }
			 
		 }
		 pLog->setFile(_filename);
		 
		 
	 }

	 void CLog::shutdown(){
		 std::map<std::string, _log*>::iterator it;
		 for (it = logs.begin(); it != logs.end(); it++){
			 _log *ele = it->second;
			 SAFEDELETE(ele);
		 }
		 
		 SAFEDELETE(defaultLog);
		 
	 }
	 
	 void CLog::log (std::string cat, std::string s){
		 getInst(cat)->log(s);
	 };
	 void CLog::warning (std::string cat, std::string s){
		 getInst(cat)->warning(s);
	 };
	 void CLog::error (std::string cat, std::string s){
		 getInst(cat)->error(s);
	 };
	 void CLog::event (std::string cat, std::string s){
		 getInst(cat)->event(s);
	 };
	 void CLog::trace (std::string cat, std::string s, int level){
		 getInst(cat)->trace(s, level);
	 };

	 void CLog::log (std::string s){
		 getDefaultInst()->log(s);
	 };
	 void CLog::warning (std::string s){
		 getDefaultInst()->warning(s);
	 };
	 void CLog::error (std::string s){
		 getDefaultInst()->error(s);
	 };
	 void CLog::event (std::string s){
		 getDefaultInst()->event(s);
	 };
	 void CLog::trace (std::string s, int level){
		 getDefaultInst()->trace(s, level);
	 };
