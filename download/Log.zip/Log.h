// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOG_H__2D2C5E5E_39B5_4FCF_957E_959CE8DF0123__INCLUDED_)
#define AFX_LOG_H__2D2C5E5E_39B5_4FCF_957E_959CE8DF0123__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*
* log.h - logging functions
*
* Please note that opening and closing of log files are not thread safe.
* Don't do it unless you're in single-thread mode.
*/

#include <map>
#include <string>
#include "Lock.h"
#include "time.h"
#include "Thread.h"

/* If we're using GCC, we can get it to check log function arguments. */
#ifdef __GNUC__
#define PRINTFLIKE __attribute__((format(printf, 2, 3)))
#define PRINTFLIKE2 __attribute__((format(printf, 3, 4)))
#else
#define PRINTFLIKE
#define PRINTFLIKE2
#endif

/* Symbolic levels for output levels. */
enum output_level {
	LOG_DEBUG, LOG_INFO, LOG_WARNING, LOG_ERROR, LOG_PANIC
};

/* Print a panicky error message and terminate the program with a failure.
* So, this function is called when there is no other choice than to exit
* immediately, with given reason
*/
void panic(int, const char *, ...) PRINTFLIKE ;

/* Print a normal error message. Used when something which should be
* investigated and possibly fixed, happens. The error might be fatal, too,
* but we have time to put system down peacefully.
*/
void error(int, const char *, ...) PRINTFLIKE ;

/* Print a warning message. 'Warning' is a message that should be told and
* distinguished from normal information (info), but does not necessary 
* require any further investigations. Like 'warning, no sender number set'
*/
void warning(int, const char *, ...) PRINTFLIKE ;

/* Print an informational message. This information should be limited to
* one or two rows per request, if real debugging information is needed,
* use debug
*/
void info(int, const char *, ...) PRINTFLIKE ;

/*
* Print a debug message. Most of the log messages should be of this level 
* when the system is under development. The first argument gives the `place'
* where the function is called from; see function set_debug_places.
*/
void debug(const char *, int, const char *, ...) PRINTFLIKE2 ;


/*
* Set the places from which debug messages are actually printed. This
* allows run-time configuration of what is and is not logged when debug
* is called. `places' is a string of tokens, separated by whitespace and/or
* commas, with trailing asterisks (`*') matching anything. For instance,
* if `places' is "wap.wsp.* wap.wtp.* wapbox", then all places that begin 
* with "wap.wsp." or "wap.wtp." (including the dots) are logged, and so 
* is the place called "wapbox". Nothing else is logged at debug level, 
* however. The 'places' string can also have negations, marked with '-' at 
* the start, so that nothing in that place is outputted. So if the string is
* "wap.wsp.* -wap.wap.http", only wap.wsp is logged, but not http-parts on 
* it
*/
void set_debug_places(const char *places);


/* Set minimum level for output messages to stderr. Messages with a lower 
level are not printed to standard error, but may be printed to files
(see below). */
void set_output_level(enum output_level level);

/*
* Set syslog usage. If `ident' is NULL, syslog is not used.
*/
void set_syslog(const char *ident, int syslog_level);

/* Start logging to a file as well. The file will get messages at least of
level `level'. There is no need and no way to close the log file;
it will be closed automatically when the program finishes. Failures
when opening to the log file are printed to stderr. */
void open_logfile(char *filename, int level);

/* Close and re-open all logfiles */
void reopen_log_files(void);

/*
* Close all log files.
*/
void close_all_logfiles(void);

/*
* Switch on or off the debug function.
*
* Added by Zhang Yuan, for normal service. 2001-3-1.
*/
#ifdef WIN32
__declspec(dllexport) void disable_debug_info(void);
__declspec(dllexport) void enable_debug_info(void);
#else
void disable_debug_info(void);
void enable_debug_info(void);
#endif


namespace clib{

class _log{
	
public:
	_log(std::string key);
	
	_log(_log& src);
	
	virtual ~_log();
	
	// attributes
private:
	bool bError;
	bool bWarning;
	bool bLog;
	bool bTrace;
	bool bEvent;
	int	nTraceLevel;
	
	bool bCache;
	int nCacheSize;
	std::string cache;
	
	CMutex lock;
	CEvent toStop;
	
	std::string file;	// log file name
	std::string category; // category name
	
	int nCurWaitNumber; // number of current waiting
	int waitTime;		// in millisecond
	int nMaxWaitNumber;	

	bool bFirstWrite; 
	
protected:
	
	
	
	void put(std::string s);
	
	void putReal(std::string s);

	static void sweeper(void* p);
	// interface
public:

	void setWarning(bool b);
	
	void setError(bool b);
	
	void setLog(bool b);
	
	void setTrace(bool b, int l);
	
	void setCache(bool b, int size);
	
	void setFile(std::string sFileName);
	
	void log(std::string s);
	
	void error(std::string s);
	
	void warning(std::string s);
	
	void trace(std::string s, int l);
	
	void event(std::string s);
	
	void flush();
	
	void setCategory(std::string key);
	
 };
 
 class CLIB_DLL_FUNC_HEAD CLog  
 {
 private:
	 static CMutex lock;
	 static _log *defaultLog;
	 static std::map<std::string, _log*> logs;
	 typedef std::pair<std::string, _log*> log_pair;
	 
 protected:
	 CLog();
	virtual ~CLog(); 
 public:

	  
	 static _log* getDefaultInst();
	 
	 static _log* getInst(std::string key);
	 
	 static bool set(std::string category, std::string fileName, bool bLog, bool bWarning, bool bError, bool bTrace, int nTraceLevel, bool bCache, int nCacheSize);
	 
	 static void setFile(std::string category, std::string filename);

	 static void shutdown();
	 
	 static void log (std::string cat, std::string s);
	 static void warning (std::string cat, std::string s);
	 static void error (std::string cat, std::string s);
	 static void event (std::string cat, std::string s);
	 static void trace (std::string cat, std::string s, int level);

	 static void log (std::string s);
	 static void warning (std::string s);
	 static void error (std::string s);
	 static void event (std::string s);
	 static void trace (std::string s, int level);
	 
 };
} 

 // define macro
#define LOG(s) {\
 char clog_line[10] = ""; itoa(__LINE__, clog_line, 10); \
 std::string str = s; str += std::string("@"##__FILE__) + std::string(":") + clog_line;\
 CLog::log(str);}

#define TRACE(s, l) {\
	char clog_line[10] = ""; itoa(__LINE__, clog_line, 10); \
	std::string str = s; str += std::string("@"##__FILE__) + std::string(":") + clog_line;\
 CLog::trace(str, l);}

#define CLIB_ERROR(s) {\
	char clog_line[10] = ""; itoa(__LINE__, clog_line, 10); \
	std::string str = s; str += std::string("@"##__FILE__) + std::string(":") + clog_line;\
 CLog::error(str);}

#define WARNING(s) {\
	char clog_line[10] = ""; itoa(__LINE__, clog_line, 10); \
	std::string str = s; str += std::string("@"##__FILE__) + std::string(":") + clog_line;\
 CLog::warning(str);}

#define EVENT(s) {\
	char clog_line[10] = ""; itoa(__LINE__, clog_line, 10); \
	std::string str = s; str += std::string("@"##__FILE__) + std::string(":") + clog_line;\
 CLog::event(str);}


#endif // !defined(AFX_LOG_H__2D2C5E5E_39B5_4FCF_957E_959CE8DF0123__INCLUDED_)

