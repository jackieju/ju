#include "stdafx.h"
#include <string>
#include <vector>
#include <windows.h>
#include "..\product\se_interface.h"


char version[10] = "1.000";
int main(int argc, char* argv[])
{	
	long ret;

	printf(	"TestSE v%s - NCSE tester\n"
			"Copyright (C) 2002 Weihua Ju\n"
			,version);
	if (argc <= 1)
	{
		printf(	"Usage: TestSe <config file name>\n");
		return 0;
	}

	// start SE
	if ((ret =SE_Start(argv[1])) !=  SEERR_NOERROR)
	{
		printf("se_start failed(%d)\n", ret);
		return 0;
	}

	// Load external lib
	if ( (ret = SE_LoadLib("BaseLib.DLL", "BaseLib.int" ) )!=  SEERR_NOERROR)
	{
		printf("SE_LoadLib failed(%d)\n", ret);
		return 0;
	}
	
	// Load external lib
	if ( (ret = SE_CompileAll())!=  SEERR_NOERROR)
	{
		printf("SE_CompileAll failed(%d)\n", ret);
		return 0;
	}

	// create NC request
	long hReq = SE_REQ_Create();
	if (hReq == NULL)
	{
		printf("Create request failed\n");
		return 0;
	}

	char sFuncName[30] = "test1";
	SE_REQ_SetFn(hReq, sFuncName);


	// add parameters
	SE_REQ_AddParamString(hReq, "hello world");
	
//	while (1)
//	{
	// run
		printf("exec nc program '%s' , result code %d\n", sFuncName, SE_ExecScript(hReq, 0, 1));

//	}

	SE_REQ_ReleaseReq(hReq);
	Sleep(1000); 

	SE_Stop(10000, 1);
	
	return 0;
}

