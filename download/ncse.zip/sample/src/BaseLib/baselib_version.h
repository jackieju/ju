#ifndef __BASELIB_VERSION_H__
#define __BASELIB_VERSION_H__

// version info
#define BASELIB_BUILDDATE __DATE__
#define BASELIB_BUILDTIME __TIME__

//////////////////////////////////////////////////////////////
#define BASELIB_VERSION _T("1.0.0 0001B")
// ------------------------------------------
// This version include following modification
// 
//////////////////////////////////////////////////////////////


#endif //__BASELIB_VERSION_H__